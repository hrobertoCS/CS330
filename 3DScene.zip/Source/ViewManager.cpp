///////////////////////////////////////////////////////////////////////////////
// viewmanager.h
// ============
// manage the viewing of 3D objects within the viewport
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "ViewManager.h"

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>    

// declaration of the global variables and defines
namespace
{
	// Variables for window width and height
	const int WINDOW_WIDTH = 1000;
	const int WINDOW_HEIGHT = 800;
	const char* g_ViewName = "view";
	const char* g_ProjectionName = "projection";

	//define camera XYZ for perspective mode
	glm::vec3 perspectivePos(0.0f, 15.0f, 25.0f);
	glm::vec3 perspectiveFront(0.0f, -0.5f, -2.0f);
	float perspectiveZoom = 80.0f;

	//define camera XYZ for orthographic mode
	glm::vec3 orthoPos(0.0f, 30.0f, 0.01f);
	glm::vec3 orthoFront(0.0f, -1.0f, 0.0f);
	float orthoZoom = 1.0f;

	


	// camera object used for viewing and interacting with
	// the 3D scene
	Camera* g_pCamera = nullptr;

	// these variables are used for mouse movement processing
	float gLastX = WINDOW_WIDTH / 2.0f;
	float gLastY = WINDOW_HEIGHT / 2.0f;
	bool gFirstMouse = true;

	// time between current frame and last frame
	float gDeltaTime = 0.0f; 
	float gLastFrame = 0.0f;

	// the following variable is false when orthographic projection
	// is off and true when it is on
	bool bOrthographicProjection = false;
}

/***********************************************************
 *  ViewManager()
 *
 *  The constructor for the class
 ***********************************************************/
ViewManager::ViewManager(
	ShaderManager *pShaderManager)
{
	// initialize the member variables
	m_pShaderManager = pShaderManager;
	m_pWindow = NULL;
	g_pCamera = new Camera();
	// default camera view parameters
	//set camerea position z to 25 to get a more zoomed out view of the scene
	//set camera position y to 15 to get a higher up point of view that looks down on scene
	g_pCamera->Position = glm::vec3(0.0f, 15.0f, 25.0f);
	g_pCamera->Front = glm::vec3(0.0f, -0.5f, -2.0f);
	g_pCamera->Up = glm::vec3(0.0f, 1.0f, 0.0f);
	g_pCamera->Zoom = 80;
}

/***********************************************************
 *  ~ViewManager()
 *
 *  The destructor for the class
 ***********************************************************/
ViewManager::~ViewManager()
{
	// free up allocated memory
	m_pShaderManager = NULL;
	m_pWindow = NULL;
	if (NULL != g_pCamera)
	{
		delete g_pCamera;
		g_pCamera = NULL;
	}
}
//sets current projection mode to perspective
enum ProjectionMode { PERSPECTIVE, ORTHOGRAPHIC };
ProjectionMode currentProjection = PERSPECTIVE;


//inverts scrolling so scrolling forward increses speed and backwards decreases it. 
void scrollCallback(GLFWwindow* window, double newX, double newY) {
	if (g_pCamera)
	{
		g_pCamera->ProcessMouseScroll(static_cast<float>(-newY) * 0.5f);
	}
}

/***********************************************************
 *  CreateDisplayWindow()
 *
 *  This method is used to create the main display window.
 ***********************************************************/
GLFWwindow* ViewManager::CreateDisplayWindow(const char* windowTitle)
{
	GLFWwindow* window = nullptr;

	// try to create the displayed OpenGL window
	window = glfwCreateWindow(
		WINDOW_WIDTH,
		WINDOW_HEIGHT,
		windowTitle,
		NULL, NULL);
	if (window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return NULL;
	}
	glfwMakeContextCurrent(window);

	// tell GLFW to capture all mouse events
	//glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

	// this callback is used to receive mouse moving events
	glfwSetCursorPosCallback(window, &ViewManager::Mouse_Position_Callback);

	// enable blending for supporting tranparent rendering
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	m_pWindow = window;

	glfwSetScrollCallback(m_pWindow, scrollCallback);

	return(window);
}


/***********************************************************
 *  Mouse_Position_Callback()
 *
 *  This method is automatically called from GLFW whenever
 *  the mouse is moved within the active GLFW display window.
 ***********************************************************/
void ViewManager::Mouse_Position_Callback(GLFWwindow* window, double xMousePos, double yMousePos)
{
	//stores previous x position 
	static float xPos = WINDOW_WIDTH / 2.0;
	//stores previous y position
	static float yPos = WINDOW_HEIGHT / 2.0;

	//calculate movement 
	float newX = static_cast<float>(xMousePos) - xPos;
	//invert Y so moving up looks up in scene
	float newY = yPos - static_cast<float>(yMousePos);

	//creates deadzone where slight movements from the mouse arent registered
	const float deadZone = 0.3f;
	if (fabs(newX) < deadZone) {
		newX = 0.0f;
	}
	if (fabs(newY) < deadZone) {
		newY = 0.0f;
	}
	float sensitivity = 0.25f;
	

	//multiplies new position by 0.9 to slow camera movement
	newX *= sensitivity;
	newY *= sensitivity;

	

	g_pCamera->ProcessMouseMovement(newX, newY);

}

//set camera's position, direction, and zoom
void SetCamera(ProjectionMode mode)
{
	if (!g_pCamera) {
		return;
	}

	if (mode == PERSPECTIVE) {

		//reset camera values for perspective view
		g_pCamera->Position = perspectivePos;
		g_pCamera->Yaw = -90.0f;
		g_pCamera->Pitch = -20.0f;
		g_pCamera->Front = glm::normalize(perspectiveFront);
		g_pCamera->Zoom = perspectiveZoom;

		g_pCamera->Up = glm::vec3(0.0f, 1.0f, 0.0f);
	}
	else if (mode == ORTHOGRAPHIC)
	{
		//reset camera values for orthographic view
		g_pCamera->Position = orthoPos;
		g_pCamera->Yaw = 0.0f;
		g_pCamera->Pitch = -90.0f;
		g_pCamera->Front = glm::normalize(orthoFront);
		g_pCamera->Zoom = orthoZoom;

		
	}

}

/***********************************************************
 *  ProcessKeyboardEvents()
 *
 *  This method is called to process any keyboard events
 *  that may be waiting in the event queue.
 ***********************************************************/
void ViewManager::ProcessKeyboardEvents()
{
	//horizontal movement
	// close the window if the escape key has been pressed
	if (glfwGetKey(m_pWindow, GLFW_KEY_ESCAPE) == GLFW_PRESS)
	{
		glfwSetWindowShouldClose(m_pWindow, true);
	}

	//move forward if W is pressed
	if (glfwGetKey(m_pWindow, GLFW_KEY_W) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(FORWARD, gDeltaTime);
	}
	
	//move backward if S is pressed
	if (glfwGetKey(m_pWindow, GLFW_KEY_S) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(BACKWARD, gDeltaTime);
	}

	//move left if A is pressed
	if (glfwGetKey(m_pWindow, GLFW_KEY_A) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(LEFT, gDeltaTime);
	}

	//move right if D is pressed 
	if (glfwGetKey(m_pWindow, GLFW_KEY_D) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(RIGHT, gDeltaTime);
	}


	//vertical movement
	//moves up if Q is presses
	if (glfwGetKey(m_pWindow, GLFW_KEY_Q) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(UP, gDeltaTime);
	}

	//moves down if E is pressed
	if (glfwGetKey(m_pWindow, GLFW_KEY_E) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(DOWN, gDeltaTime);
	}

	
	// Projection switching
	//switch to perspective
	if (glfwGetKey(m_pWindow, GLFW_KEY_P) == GLFW_PRESS) {


		currentProjection = PERSPECTIVE;
		SetCamera(PERSPECTIVE);
	}
	//switch to orthographic
	if (glfwGetKey(m_pWindow, GLFW_KEY_O) == GLFW_PRESS) {
		currentProjection = ORTHOGRAPHIC;
		SetCamera(ORTHOGRAPHIC);
	}
	
}


 

/***********************************************************
 *  PrepareSceneView()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void ViewManager::PrepareSceneView()
{
	glm::mat4 view;
	glm::mat4 projection;

	// per-frame timing
	float currentFrame = glfwGetTime();
	gDeltaTime = currentFrame - gLastFrame;
	gLastFrame = currentFrame;

	// process any keyboard events that may be waiting in the 
	// event queue
	ProcessKeyboardEvents();

	// get the current view matrix from the camera
	view = g_pCamera->GetViewMatrix();

	// define the current projection matrix
	//checks which projection mode is being used
	if (currentProjection == ORTHOGRAPHIC)
	{
		projection = glm::ortho(-20.0f, 20.0f, -20.0f, 20.0f, 0.1f, 100.0f);
	}
	else {
		projection = glm::perspective(glm::radians(g_pCamera->Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
	}
	// if the shader manager object is valid
	if (NULL != m_pShaderManager)
	{
		// set the view matrix into the shader for proper rendering
		m_pShaderManager->setMat4Value(g_ViewName, view);
		// set the view matrix into the shader for proper rendering
		m_pShaderManager->setMat4Value(g_ProjectionName, projection);
		// set the view position of the camera into the shader for proper rendering
		m_pShaderManager->setVec3Value("viewPosition", g_pCamera->Position);
	}
	
}